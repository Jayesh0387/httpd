### What it does
A simple dockerbuild file for apache webserver for any docker registy

